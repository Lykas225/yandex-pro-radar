package ru.radar.koef

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("radar", Context.MODE_PRIVATE)

    fun load(): Cfg = Cfg(
        costPerKm = p.getFloat("cost", 8f).toDouble(),
        minPerKm = Tariff.entries.associateWith { p.getFloat("km_${it.name}", it.defKm.toFloat()).toDouble() },
        minPerHour = Tariff.entries.associateWith { p.getFloat("hour_${it.name}", it.defHour.toFloat()).toDouble() }
    )

    fun save(cost: Double, km: Map<Tariff, Double>, hour: Map<Tariff, Double>) {
        p.edit().apply {
            putFloat("cost", cost.toFloat())
            Tariff.entries.forEach {
                putFloat("km_${it.name}", (km[it] ?: it.defKm).toFloat())
                putFloat("hour_${it.name}", (hour[it] ?: it.defHour).toFloat())
            }
        }.apply()
    }

    fun loadPos(defaultY: Int): Pair<Int, Int> = p.getInt("px", 0) to p.getInt("py", defaultY)

    fun savePos(x: Int, y: Int) {
        p.edit().putInt("px", x).putInt("py", y).apply()
    }
}
