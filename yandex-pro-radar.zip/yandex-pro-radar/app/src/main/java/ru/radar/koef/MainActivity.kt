package ru.radar.koef

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val kmF = mutableMapOf<Tariff, EditText>()
    private val hourF = mutableMapOf<Tariff, EditText>()
    private lateinit var costF: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val cfg = Store(this).load()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(s: String, size: Float = 15f) = TextView(this).apply {
            text = s
            textSize = size
            setPadding(0, pad / 2, 0, 0)
        }
        fun button(s: String, onClick: () -> Unit) = Button(this).apply {
            text = s
            setOnClickListener { onClick() }
        }
        fun field(v: Double, hintText: String) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(if (v % 1.0 == 0.0) v.toInt().toString() else v.toString())
            hint = hintText
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        root.addView(label("Радар кэфа для Яндекс Про", 22f))
        status = label("")
        root.addView(status)
        root.addView(label("1) Если служба не включается (Android 13+ при установке из APK): откройте «О приложении» → ⋮ → «Разрешить ограниченные настройки»."))
        root.addView(button("О приложении") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(label("2) Включите службу «Радар кэфа» в спецвозможностях."))
        root.addView(button("Спецвозможности") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(label("Расход на 1 км (топливо + износ), ₽", 16f))
        costF = field(cfg.costPerKm, "₽/км").also {
            it.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(costF)

        root.addView(label("Пороги выгодности по тарифам (минимум ₽/км и ₽/час)", 16f))
        for (t in Tariff.entries) {
            root.addView(label(t.title))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val k = field(cfg.minPerKm.getValue(t), "₽/км")
            val h = field(cfg.minPerHour.getValue(t), "₽/час")
            kmF[t] = k
            hourF[t] = h
            row.addView(k)
            row.addView(h)
            root.addView(row)
        }
        root.addView(button("Сохранить") { save() })

        setContentView(ScrollView(this).apply {
            fitsSystemWindows = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains("RadarService") == true
        status.text = if (enabled) "Служба: включена ✓" else "Служба: выключена ✗"
    }

    private fun num(e: EditText): Double? = e.text.toString().replace(',', '.').toDoubleOrNull()

    private fun save() {
        val km = Tariff.entries.associateWith { num(kmF.getValue(it)) ?: it.defKm }
        val hour = Tariff.entries.associateWith { num(hourF.getValue(it)) ?: it.defHour }
        Store(this).save(num(costF) ?: 9.0, km, hour)
        Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
    }
}
