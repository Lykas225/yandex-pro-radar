package ru.radar.koef

object Profit {
    fun evaluate(o: Order, cfg: Cfg): Result {
        val perKm = o.price / o.km.coerceAtLeast(0.1)
        val perHour = o.price / (o.minutes.coerceAtLeast(1) / 60.0)
        val net = o.price - o.km * cfg.costPerKm
        val minKm = cfg.minPerKm[o.tariff] ?: o.tariff.defKm
        val minHour = cfg.minPerHour[o.tariff] ?: o.tariff.defHour
        return Result(o, perKm, perHour, net, ok = perKm >= minKm && perHour >= minHour)
    }
}
