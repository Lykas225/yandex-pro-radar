package ru.radar.koef

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

class RadarService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private var overlay: OverlayView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val hideTask = Runnable { removeOverlay() }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = Store(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != YANDEX_PRO) return

        val texts = ArrayList<String>()
        collect(root, texts)
        val order = OrderParser.parse(texts)

        if (order == null) {
            // карточка пропала — убираем плашку с небольшой задержкой, чтобы не мигала
            handler.removeCallbacks(hideTask)
            handler.postDelayed(hideTask, 1500)
            return
        }
        handler.removeCallbacks(hideTask)
        showOverlay(Profit.evaluate(order, store.load()))
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        n ?: return
        n.text?.let { out += it.toString() }
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    private fun showOverlay(r: Result) {
        overlay?.let { it.show(r); return }

        val d = resources.displayMetrics.density
        val (px, py) = store.loadPos((80 * d).toInt())
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = px
            y = py
        }
        val view = OverlayView(this)
        view.setOnTouchListener(dragListener(params, view))
        view.show(r)
        wm.addView(view, params)
        view.popIn()
        overlay = view
    }

    /** Перетаскивание плашки; короткий тап сворачивает/разворачивает; позиция запоминается. */
    private fun dragListener(params: WindowManager.LayoutParams, view: OverlayView): View.OnTouchListener {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) store.savePos(params.x, params.y) else view.toggleCompact()
                    true
                }
                else -> false
            }
        }
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
    }

    override fun onInterrupt() = removeOverlay()

    override fun onDestroy() {
        handler.removeCallbacks(hideTask)
        removeOverlay()
        super.onDestroy()
    }

    companion object {
        const val YANDEX_PRO = "ru.yandex.taximeter"
    }
}
