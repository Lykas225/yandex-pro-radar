package ru.radar.koef

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/** Всплывающая плашка: зелёная — выгодно, красная — нет. Тап сворачивает, перетаскивание двигает. */
class OverlayView(ctx: Context) : LinearLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val title = tv(18f)
    private val l1 = tv(15f)
    private val l2 = tv(15f)
    private val l3 = tv(15f)
    private var compact = false
    private var last: Result? = null

    init {
        orientation = VERTICAL
        val p = (12 * d).toInt()
        setPadding(p, p, p, p)
        listOf(title, l1, l2, l3).forEach { addView(it) }
    }

    private fun tv(size: Float) = TextView(context).apply {
        textSize = size
        setTextColor(0xFFFFFFFF.toInt())
    }

    fun show(r: Result) {
        last = r
        background = GradientDrawable().apply {
            cornerRadius = 14 * d
            setColor(if (r.ok) 0xEE1B8A3A.toInt() else 0xEEC62828.toInt())
        }
        val o = r.order
        title.text = (if (r.ok) "ВЫГОДНО ✓" else "НЕ ВЫГОДНО ✗") + "  •  " + o.tariff.title
        l1.text = String.format(Locale.US, "Цена %d ₽  •  коэф. ×%.1f", o.price, o.coef)
        l2.text = String.format(Locale.US, "В пути %d мин  •  %.1f км", o.minutes, o.km)
        l3.text = String.format(Locale.US, "%.0f ₽/км  •  %.0f ₽/ч  •  чистыми %.0f ₽", r.perKm, r.perHour, r.net)
        val detailsVisibility = if (compact) View.GONE else View.VISIBLE
        l2.visibility = detailsVisibility
        l3.visibility = detailsVisibility
        visibility = View.VISIBLE
    }

    fun toggleCompact() {
        compact = !compact
        last?.let { show(it) }
    }

    fun popIn() {
        alpha = 0f
        scaleX = 0.85f
        scaleY = 0.85f
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
    }
}
