package ru.radar.koef

enum class Tariff(val title: String, val keys: List<String>, val defKm: Double, val defHour: Double) {
    // порядок важен: "Комфорт+" проверяется раньше "Комфорт"
    COMFORT_PLUS("Комфорт+", listOf("комфорт+", "комфорт плюс"), 60.0, 1500.0),
    COMFORT("Комфорт", listOf("комфорт"), 48.0, 1200.0),
    ECONOM("Эконом", listOf("эконом"), 29.0, 725.0);

    companion object {
        /** Тарифы, которые радар не оценивает: на них плашка не показывается. */
        private val ignored = listOf("бизнес", "доставк", "курьер", "грузов")

        /**
         * Находит тариф в тексте карточки. Если названия нет вовсе, считаем Эконом.
         * Для неподдерживаемых тарифов (Бизнес, Доставка и т.д.) возвращает null.
         */
        fun detect(text: String): Tariff? {
            val t = text.lowercase()
            entries.firstOrNull { tariff -> tariff.keys.any { k -> t.contains(k) } }?.let { return it }
            return if (ignored.any { t.contains(it) }) null else ECONOM
        }
    }
}

data class Order(
    val price: Int,
    val coef: Double,
    val minutes: Int,
    val km: Double,
    val tariff: Tariff
)

data class Cfg(
    val costPerKm: Double,
    val minPerKm: Map<Tariff, Double>,
    val minPerHour: Map<Tariff, Double>
)

data class Result(
    val order: Order,
    val perKm: Double,
    val perHour: Double,
    val net: Double,
    val ok: Boolean
)
