package ru.radar.koef

enum class Tariff(val title: String, val keys: List<String>, val defKm: Double, val defHour: Double) {
    // порядок важен: "Комфорт+" проверяется раньше "Комфорт"
    COMFORT_PLUS("Комфорт+", listOf("комфорт+", "комфорт плюс"), 32.0, 900.0),
    COMFORT("Комфорт", listOf("комфорт"), 28.0, 800.0),
    ECONOM("Эконом", listOf("эконом"), 25.0, 700.0),
    BUSINESS("Бизнес", listOf("бизнес"), 35.0, 1000.0),
    DELIVERY("Доставка", listOf("доставк"), 25.0, 600.0),
    COURIER("Курьер", listOf("курьер"), 20.0, 500.0),
    CARGO("Грузовой", listOf("грузов"), 30.0, 900.0),
    OTHER("Другое", emptyList(), 25.0, 700.0);

    companion object {
        fun detect(text: String): Tariff {
            val t = text.lowercase()
            return entries.firstOrNull { tariff -> tariff.keys.any { k -> t.contains(k) } } ?: OTHER
        }
    }
}

data class Order(
    val price: Int,
    val coef: Double,
    val minutes: Int,
    val km: Double,
    val tariff: Tariff
)

data class Cfg(
    val costPerKm: Double,
    val minPerKm: Map<Tariff, Double>,
    val minPerHour: Map<Tariff, Double>
)

data class Result(
    val order: Order,
    val perKm: Double,
    val perHour: Double,
    val net: Double,
    val ok: Boolean
)
