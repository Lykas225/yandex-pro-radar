package ru.radar.koef

/** Достаёт параметры заказа из текстов экрана Яндекс Про. Чистый Kotlin, без Android. */
object OrderParser {
    private val price = Regex("""(\d[\d ]*(?:[.,]\d+)?)\s?₽""")
    private val coefA = Regex("""[x×х]\s?(\d+(?:[.,]\d+)?)""", RegexOption.IGNORE_CASE)
    private val coefB = Regex("""(\d+[.,]\d+)\s?[x×х](?![\p{L}])""", RegexOption.IGNORE_CASE)
    private val hours = Regex("""(\d+)\s?ч(?:ас\p{L}*)?(?![\p{L}])""")
    private val mins = Regex("""(\d+)\s?мин""")
    private val km = Regex("""(\d+(?:[.,]\d+)?)\s?км""")
    private val meters = Regex("""(\d+)\s?м(?![\p{L}])""")

    /** Возвращает null, если на экране не карточка заказа (нужны цена, время и расстояние). */
    fun parse(texts: List<String>): Order? {
        val s = texts.joinToString(" | ").replace('\u00A0', ' ').replace('\u202F', ' ')

        val p = price.findAll(s)
            .mapNotNull { it.groupValues[1].replace(" ", "").replace(',', '.').toDoubleOrNull() }
            .maxOrNull()?.toInt() ?: return null

        val minutes = hours.findAll(s).sumOf { it.groupValues[1].toInt() * 60 } +
            mins.findAll(s).sumOf { it.groupValues[1].toInt() }

        val distance = km.findAll(s).sumOf { it.groupValues[1].replace(',', '.').toDouble() } +
            meters.findAll(s).sumOf { it.groupValues[1].toInt() } / 1000.0

        if (p <= 0 || minutes <= 0 || distance <= 0.0) return null

        val coef = (coefA.find(s) ?: coefB.find(s))
            ?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()
            ?.takeIf { it in 1.0..10.0 } ?: 1.0

        val tariff = Tariff.detect(s) ?: return null
        return Order(p, coef, minutes, distance, tariff)
    }
}
