package ru.radar.koef

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class OrderParserTest {
    @Test
    fun parsesOrderCard() {
        val o = OrderParser.parse(listOf("Комфорт", "450 ₽", "x1,5", "5 мин • 2,1 км", "22 мин • 11 км"))
        assertNotNull(o)
        assertEquals(450, o!!.price)
        assertEquals(1.5, o.coef, 0.001)
        assertEquals(27, o.minutes)
        assertEquals(13.1, o.km, 0.001)
        assertEquals(Tariff.COMFORT, o.tariff)
    }

    @Test
    fun ignoresNonOrderScreen() {
        assertNull(OrderParser.parse(listOf("Баланс", "1 200 ₽")))
    }

    @Test
    fun evaluatesProfit() {
        val cfg = Cfg(8.0, Tariff.entries.associateWith { 25.0 }, Tariff.entries.associateWith { 700.0 })
        val good = Profit.evaluate(Order(450, 1.5, 27, 13.1, Tariff.ECONOM), cfg)
        val bad = Profit.evaluate(Order(150, 1.0, 40, 12.0, Tariff.ECONOM), cfg)
        assertEquals(true, good.ok)
        assertEquals(false, bad.ok)
    }
}
